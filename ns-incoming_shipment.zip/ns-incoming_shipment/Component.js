sap.ui.define(['sap/ui/core/UIComponent'],
	function(UIComponent) {
	"use strict";

	var Component = UIComponent.extend("ns.incoming_shipment.Component", {

		metadata : {
			manifest: "json"
		}
	});

	return Component;

});
